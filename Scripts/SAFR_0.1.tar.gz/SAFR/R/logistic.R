# logistic function
logistic <- function(a,b,x){
1 / (1  + exp( a - b * x));
}
